Настройки для Flying Bear Ghost 5 + MKS Robin Nano v1.2:

- Экструдер: TMC2209
- Направление экструдера исправлено
- INVERT_E0_DIR = true
- E0_DRIVER_TYPE = TMC2209

Как собрать:
1. Открыть проект в VSCode + PlatformIO
2. Нажать Build у mks_robin_nano_v1v2
3. Взять файл:
   .pio/build/mks_robin_nano_v1v2/firmware.bin
4. Переименовать в Robin_nano35.bin
5. Скопировать на SD карту
